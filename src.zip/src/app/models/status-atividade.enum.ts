export enum StatusAtividade {
  PENDENTE = 'Pendente',
  EM_ANDAMENTO = 'Em andamento',
  CONCLUIDA = 'Concluída',
  CANCELADA = 'Cancelada'
}