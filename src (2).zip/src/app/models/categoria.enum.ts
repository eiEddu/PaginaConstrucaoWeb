export enum CategoriaAtividade {
  FUTEBOL = 'Futebol',
  VOLEI = 'Vôlei',
  BASQUETE = 'Basquete',
  TENIS = 'Tênis'
}