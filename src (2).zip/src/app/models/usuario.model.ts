export interface Usuario {
  id?: number;          // gerado pelo IndexedDB
  nomeCompleto: string;
  email: string;
  contato:string;
}